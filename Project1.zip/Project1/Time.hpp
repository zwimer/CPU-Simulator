#ifndef Time_hpp
#define Time_hpp

//Forward declarations
class Algo;
class PList;


//Small time class. The reason this is a
//class is to prevent accidental changes of t
//Note, t2 is just the previous time, used only when t = -1
class Time {
public:
    
    //Constructor
    Time();
    
    //Functions
    const int getTime() const;
    const int getLastTime() const;
    
private:
    
    //Allow time to be changed by RunAlgo
    friend void RunAlgo(PList*, Algo&);
    
    //Set the time
    void setTime(int a);
    
    //Representation
    int t, t2;
    
    //Statics for error checking
    static int numTime;
};

#endif /* Time_hpp */
